﻿JSON Serialesieren kann weggelassen werden, da es n Bit Arrays gespeichert wird.
Für den Tomb Stone wird ein eigernes Boolean Feld im Entry verwendet. Ich weis nähmlich nicht wie ich den Tomb Stone machen kann ohne das es zu fehlern kommen könnte.

Die File Namen waren als datums Zahl geplant (08.06.2022 => 08062022) mit vortlaufender Nummer, aber da die Unique File ID nicht funktioniert, da es anscheinend geschützt ist, nehme ich eine GUID als namen und als Unique File ID.